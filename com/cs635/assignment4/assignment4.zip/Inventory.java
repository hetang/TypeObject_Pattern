package com.cs635.assignment4;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Set;
import java.util.TreeMap;

public class Inventory {
	private HashMap<String,Movie> m_hashNameMap = new HashMap<String,Movie>();
	private TreeMap<Double,Movie> m_hashIdSortedMap = new TreeMap<Double,Movie>();
	
	public double addNewMovie(String pCategoryName,String pTitle, String pDirector, String pReleaseDate, int pRating){
		double l_dblLastKey = 0;
		if(m_hashIdSortedMap != null && m_hashIdSortedMap.size() > 0){
			l_dblLastKey = m_hashIdSortedMap.lastKey();
		}
		Movie objNewMovie = new Movie(++l_dblLastKey,pTitle,pDirector,pReleaseDate,pRating);
		objNewMovie.setCategory(pCategoryName);
		m_hashIdSortedMap.put(objNewMovie.getId(), objNewMovie);
		m_hashNameMap.put(pTitle, objNewMovie);
		return objNewMovie.getId();
	}
	
	public Movie findMovie(double p_dblMovieId,String p_strMovieName){
		Movie objMovie = null;
		if(p_dblMovieId != 0){
			objMovie = m_hashIdSortedMap.get(p_dblMovieId);
		}else if(p_strMovieName != null){
			objMovie = m_hashNameMap.get(p_strMovieName);
		}
		
		return objMovie;
	}
	
	public ArrayList<Movie> findMovieByCategory(String pCategoryName){
		ArrayList<Movie> lobjCategoryMovieList = new ArrayList<Movie>();
		for ( String strKey : m_hashNameMap.keySet() ){
			Movie lobjMovie = m_hashNameMap.get(strKey);
			if(pCategoryName.equals(lobjMovie.getCategoryName())){
				lobjCategoryMovieList.add(lobjMovie);
			}
        }
		return lobjCategoryMovieList;

	}
	
	public ArrayList<Movie> findMovieByDirector(String pDirector){
		ArrayList<Movie> lobjDirectorMovieList = new ArrayList<Movie>();
		for ( String strKey : m_hashNameMap.keySet() ){
			Movie lobjMovie = m_hashNameMap.get(strKey);
			if(pDirector.equals(lobjMovie.getDirector())){
				lobjDirectorMovieList.add(lobjMovie);
			}
        }
		return lobjDirectorMovieList;

	}
	
	public ArrayList<RentablesItem> findDVDsForCategory(String pCategoryName){
		ArrayList<RentablesItem> objDVDRentables = new ArrayList<RentablesItem>();
		ArrayList<Movie> objMovieList = findMovieByCategory(pCategoryName);
		for(int i=0;i<objMovieList.size();i++){
			objDVDRentables.addAll(objMovieList.get(i).getDVDRentables());
		}
		
		return objDVDRentables;
	}
	
	public double findPriceofMovie(double p_dblMovieId,String p_strMovieName){
		Movie objMovie = findMovie(p_dblMovieId,p_strMovieName);
		if(null != objMovie){
			return objMovie.getPrice();
		}
		
		return 0;
	}
	
	public int findQunatitiesofMovie(double p_dblMovieId,String p_strMovieName){
		Movie objMovie = findMovie(p_dblMovieId,p_strMovieName);
		if(null != objMovie){
			return objMovie.getQuantities();
		}
		
		return 0;
	}
	
	public boolean addDVDCopies(double p_dblMovieId,String p_strMovieName,int pMovieQuantities){
		Movie objMovie = findMovie(p_dblMovieId,p_strMovieName);
		if(null != objMovie){
			return objMovie.addDVDCopies(pMovieQuantities);
		}
		
		return false;
	}
	
	public boolean addVideotapesCopies(double p_dblMovieId,String p_strMovieName,int pMovieQuantities){
		Movie objMovie = findMovie(p_dblMovieId,p_strMovieName);
		if(null != objMovie){
			return objMovie.addVideotapeCopies(pMovieQuantities);
		}
		
		return false;
	}
	
	public boolean rentDVDMovie(double p_dblMovieId,String p_strMovieName,String pRenterName){
		Movie objMovie = findMovie(p_dblMovieId,p_strMovieName);
		if(null != objMovie){
			return rentMovie(objMovie.getDVDRentables(),pRenterName);			
		}
		
		return false;
	}
	
	public boolean rentVideotapesMovie(double p_dblMovieId,String p_strMovieName,String pRenterName){
		Movie objMovie = findMovie(p_dblMovieId,p_strMovieName);
		if(null != objMovie){
			return rentMovie(objMovie.getVideotapesRentables(),pRenterName);			
		}
		
		return false;
	}
	
	private boolean rentMovie(ArrayList<RentablesItem> objDVDRentables, String pRenterName){
		for(int i=0;i<objDVDRentables.size();i++){
			RentablesItem objRentableItem = objDVDRentables.get(i);
			if(!objRentableItem.m_blnRented){
				objRentableItem.m_blnRented = true;
				objRentableItem.m_strRenterName = pRenterName;
				return true;
			}
		}
		
		return false;
	}
}